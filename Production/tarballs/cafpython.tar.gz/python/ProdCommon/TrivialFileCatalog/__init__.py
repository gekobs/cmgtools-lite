#!/usr/bin/env python
"""
Util for creating and manipulating trivial file catalogs
"""