#!/usr/bin/env python
from cmsRm import *
import cmsStage
import unittest
import os
import tempfile

class TestCMSRm( unittest.TestCase ):
    """
    __TestCMSRm__
    
    TestCase for making sure the cmsRm utility does exactly what is
    expected.
    
    $Id: cmsRm_t.py,v 1.1 2011/09/09 20:37:14 gowdy Exp $
    
    """
    fileList = [ "/store/user/gowdy/rmTest",
                      "/store/user/gowdy/rfio/rmTest",
                      "/tmp/gowdy/rmTest" ]

    def test_help( self ):
        self.assertRaises( SystemExit, main, ['-h'] )
    def test_noArgs( self ):
        self.assertRaises( SystemExit, main, [] )
    def test_removeExisting( self ):
        # copy a file to various places them rm
        for file in self.fileList:
            cmsStage.main( [ "/store/user/gowdy/test", file ] )
            self.assertFalse( main( [file] ) )
    def test_removeNonExisting( self ):
        # try to remove non-existing files
        for file in self.fileList:
            self.assertRaises( SystemExit, main, [ file ] )


if __name__ == '__main__':
    unittest.main()
