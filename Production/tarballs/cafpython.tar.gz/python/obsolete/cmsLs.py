#!/usr/bin/env python
"""
_cmsStage_

Get files in and out of SE using various LFNs

"""

import sys
import os
import getopt
import cmsIO

def main( argv ):
    (args, options ) = parseOpts( argv )

    exitcode=0
    for arg in args:
        entity = cmsIO.cmsFile( arg, "eos" )
        print entity.ls( options )
        if entity.exitcode != 0:
            exitcode=entity.exitcode
    if ( exitcode != 0 ):
        sys.exit( exitcode )

def parseOpts( argv ):
    """
    _parseOpts_

    Parse the command line arguments
    """

    options = []

    try:
        opts, args = getopt.getopt(argv, "ldhR", ["help"])
    except getopt.GetoptError:
        print >> sys.stderr, "Unable to parse argument list"
        usage()
        sys.exit(2)

    for o, a in opts:
        if o in ("-h", "--help"):
            usage()
            sys.exit()
        if o in ("-l", "-d", "-R"):
            options.append( o )

    if len(args) == 0:
        print >> sys.stderr, "Expected at least one non-option argument"
        usage()
        sys.exit(2)

    return ( args, options )

def usage():
    print """
cmsLs: [-ldhR] <dir/file> <dir/file> ...

<dir/file> can be LFNs or local file names

A LFN should be CMS standard starting /store/.
A local file name can be relative or absolute path name.

-h produce this message
-l long listing
-R recusrive (if supported by storage element)
-d list directory entry instead of contents (if supported by storage element)
"""

if __name__ == '__main__':
    main( sys.argv[1:] )
