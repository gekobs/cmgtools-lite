#!/usr/bin/env python
from cmsStage import *
import unittest
import os
import tempfile

class TestCMSStage( unittest.TestCase ):
    """
    __TestCMSStage__
    
    TestCase for making sure the cmsStage utilities does exactly what is
    expected.
    
    $Id: cmsStage_t.py,v 1.9 2011/09/13 16:59:16 gowdy Exp $
    
    """

    def setUpArgs( self ):
        self.lclSource = "/tmp/gowdy/test"
        self.lclSourceDir = tempfile.mktemp()
        self.lclSourceMissing = tempfile.mktemp()
        self.lclDestination = tempfile.mktemp()
        self.lclDestinationDir = tempfile.mktemp()
        self.lclDestinationExisting = tempfile.mktemp()
        s = open( self.lclSource, "w" )
        de = open( self.lclDestinationExisting, "w" )
        s.write( "sourceFile" )
        de.write( "destinationFile" )
        s.close()
        de.close()
        os.mkdir( self.lclSourceDir )
        os.mkdir( self.lclDestinationDir )
        lclSources = [  self.lclSource,  self.lclSourceDir,  self.lclSourceMissing ]
        lclDestinations = [ self.lclDestination,
                            self.lclDestinationDir,
                            self.lclDestinationExisting ]

        self.xrdSource = "/store/user/gowdy/test"
        self.xrdSourceDir = "/store/user/gowdy"
        self.xrdSourceMissing = "/store/user/gowdy/testNot"
        self.xrdDestination = "/store/eos/user/gowdy/test1"
        self.xrdDestinationDir = "/store/eos/user/gowdy/test"
        self.xrdDestinationExisting = "/store/eos/user/gowdy/test/testExisting"

        self.rfioSource = "/store/user/gowdy/rfio/test"
        self.rfioSourceDir = "/store/user/gowdy/rfio"
        self.rfioSourceMissing = "/store/user/gowdy/rfio/testNot"
        self.rfioDestination = "/store/user/gowdy/rfio/testD/test1"
        self.rfioDestinationDir = "/store/user/gowdy/rfio/testD"
        self.rfioDestinationExisting = "/store/user/gowdy/rfio/testD/testExisting"

        goodSources = [ self.lclSource, self.xrdSource, self.rfioSource ]
        badSources =  [ self.lclSourceDir, self.lclSourceMissing,
                        self.xrdSourceDir, self.xrdSourceMissing,
                        self.rfioSourceDir, self.rfioSourceMissing ]
        goodDestinations = [ self.lclDestination,  self.lclDestinationDir, 
                             self.xrdDestination, self.xrdDestinationDir, 
                             self.rfioDestination, self.rfioDestinationDir ]
        badDestinations =  [ self.lclDestinationExisting,
                             self.xrdDestinationExisting,
                             self.rfioDestinationExisting ]

        self.shouldPass = []
        self.shouldFail = []
        for source in goodSources:
            for destination in goodDestinations:
                if source in lclSources and \
                        destination in lclDestinations:
                    self.shouldFail.append( [ source, destination ] )
                else:
                    self.shouldPass.append( [ source, destination ] )
        for source in badSources:
            for destination in goodDestinations + badDestinations:
                self.shouldFail.append( [ source, destination ] )
        for source in goodSources:
            for destination in badDestinations:
                self.shouldFail.append( [ source, destination ] )
        self.removeDestinations()

    def tearDownArgs( self ):
        self.removeDestinations()
        os.unlink( self.lclSource )
        os.unlink( self.lclDestinationExisting )
        os.rmdir( self.lclSourceDir )
        os.rmdir( self.lclDestinationDir )
        
    def removeDestinations( self ):
        try:
            os.unlink( self.lclDestination )
        except OSError:
            pass
        try:
            os.unlink( self.lclDestinationDir + "/test" )
        except OSError:
            pass
        self.nsRM( self.xrdDestination )
        self.nsRM( self.xrdDestinationDir + "/test" )
        self.eosRM( self.xrdDestination )
        self.eosRM( self.xrdDestinationDir + "/test" )
        self.nsRM( self.rfioDestination )
        self.nsRM( self.rfioDestinationDir + "/test" )

    def nsRM( self, lfn ):
        nsname = cmsFile( lfn, 'rfio' ).path
        command = [ "nsrm", nsname ]
        (out,err) = subprocess.Popen( command,
                                      stdout=subprocess.PIPE,
                                      stderr=subprocess.PIPE ).communicate()

    def eosRM( self, lfn ):
        nsname = cmsFile( lfn, 'rfio' ).path
        command = [ "/afs/cern.ch/user/a/apeters/public/eoscms", "rm", nsname ]
        (out,err) = subprocess.Popen( command,
                                      stdout=subprocess.PIPE,
                                      stderr=subprocess.PIPE ).communicate()

    def test_help( self ):
        self.assertRaises( SystemExit, main, ['-h'] )
    def test_noArgs( self ):
        self.assertRaises( SystemExit, main, [] )
    def test_cmsFile( self ):
        self.setUpArgs()
        goodFiles = [ cmsFile( self.lclSource, 'rfio' ),
                      cmsFile( self.xrdSource, 'rfio' ),
                      cmsFile( self.rfioSource, 'rfio' ) ]
        for myFile in goodFiles:
            self.assertTrue( myFile.isfile() )
            self.assertTrue( len( myFile.stat() ) > 0 )
            self.assertTrue( myFile.size() > 0 )
            self.assertFalse( myFile.isdir() )
        goodDirs = [ cmsFile( self.lclSourceDir,  'rfio' ),
                     cmsFile( self.xrdSourceDir, 'rfio' ),
                     cmsFile( self.rfioSourceDir, 'rfio' ) ]
        for myDir in goodDirs:
            self.assertFalse( myDir.isfile() )
            self.assertTrue( len( myDir.stat() ) > 0 )
            if myDir.path.startswith( "/castor/" ):
                self.assertTrue( myDir.size() == 0 )
            else:
                self.assertTrue( myDir.size() > 0 )
            self.assertTrue( myDir.isdir() )

    def test_args( self ):
        self.setUpArgs()
        for args in self.shouldPass:
            result = main( args )
            self.assertFalse( result )
            self.removeDestinations()
        for args in self.shouldFail:
            self.assertRaises( SystemExit, main, args )
            self.removeDestinations()
        self.tearDownArgs()
    def test_force( self ):
        self.setUpArgs()
        existingDestinations = [ ( self.xrdSource, self.lclDestinationExisting ),
                                 ( self.xrdSource, self.xrdDestinationExisting ),
                                 ( self.xrdSource, self.rfioDestinationExisting )]
        for args in existingDestinations:
            self.assertRaises( SystemExit, main, args )
        for args in existingDestinations:
            result = main( [ "-f", args[0], args[1] ] )
            self.assertFalse( result )


if __name__ == '__main__':
    unittest.main()
