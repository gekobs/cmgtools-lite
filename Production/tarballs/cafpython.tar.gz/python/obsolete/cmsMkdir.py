#!/usr/bin/env python
"""
_cmsStage_

Get files in and out of SE using various LFNs

"""

import sys
import os
import getopt
import cmsIO

def main( argv ):
    (args, options ) = parseOpts( argv )

    for arg in args:
        entity = cmsIO.cmsFile( arg, "eos" )
        entity.mkdir( options )

def parseOpts( argv ):
    """
    _parseOpts_

    Parse the command line arguments
    """

    options = []

    try:
        opts, args = getopt.getopt(argv, "ph", ["help"])
    except getopt.GetoptError:
        print >> sys.stderr, "Unable to parse argument list"
        usage()
        sys.exit(2)

    for o, a in opts:
        if o in ("-h", "--help"):
            usage()
            sys.exit()
        if o in ("-p"):
            options.append( o )

    if len(args) == 0:
        print >> sys.stderr, "Expected at least one non-option argument"
        usage()
        sys.exit(2)

    return ( args, options )

def usage():
    print """
cmsMkdir: [-ldhR] <dir/file> <dir/file> ...

<dir/file> can be LFNs or local file names

A LFN should be CMS standard starting /store/.
A local file name can be relative or absolute path name.

-h produce this message
-p make all intermediate directories too (if supported by storage element)
"""

if __name__ == '__main__':
    main( sys.argv[1:] )
