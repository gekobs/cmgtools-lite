#!/usr/bin/env python
"""
_cmsStage_

Get files in and out of SE using various LFNs

"""

import sys
import os
import getopt
import tempfile
from cmsIO import *

def main( argv ):

    (args, debug, force ) = parseOpts( argv )

    source = cmsFile( args[0], "eos" )
    destination = cmsFile( args[1], "eos" )

    checkArgs( source, destination, force )

    if source.protocol == "Local":
        command = getCommand( destination.protocol, force )
    else:
        command = getCommand( source.protocol, force )

    command.append( source.pfn )
    # if we are reading and writing different protocols we need to
    # make a local copy first
    tempFile = None
    if not ( source.protocol == "Local" or destination.protocol == "Local" or \
                 source.protocol == destination.protocol ):
        tempFile = cmsFile( tempfile.mktemp(), "Local" )
        command.append( tempFile.pfn )
        executeCommand( command, debug )
        validateCopy( source, tempFile, debug )
        command = getCommand( destination.protocol, force )
        command.append( tempFile.pfn )

    command.append( destination.pfn )
    executeCommand( command, debug )
    validateCopy( source, destination, debug )

    if tempFile:
        os.remove( tempFile.pfn )

def parseOpts( argv ):
    """
    _parseOpts_

    Parse the command line arguments
    """

    force = False
    debug = False

    try:
        opts, args = getopt.getopt(argv, "fdh", ["help","force","debug"])
    except getopt.GetoptError:
        print >> sys.stderr, "Unable to parse argument list"
        usage()
        sys.exit(2)

    for o, a in opts:
        if o in ("-h", "--help"):
            usage()
            sys.exit()
        if o in ("-f", "--force"):
            force=True
        if o in ("-d", "--debug"):
            debug=True

    if len(args) != 2:
        print >> sys.stderr, "Expected exactly two non-option argument"
        usage()
        sys.exit(2)

    return ( args, debug, force )

def checkArgs( source, destination, force ):
    """
    _checkArgs_

    check all arguments are suitable
    """

    if source.protocol == "Local" and \
       destination.protocol == "Local":
        print >> sys.stderr, "No LFN supplied or does not begin with /store/"
        sys.exit(2)

    if source.isdir():
        print >> sys.stderr, "Source specified is a directory, can't do anything"
        sys.exit(1)

    # if there is only a directory specified use the same basename as LFN
    if destination.isdir():
        newPath = destination.lfn + '/' + os.path.basename( source.lfn )
        destination.__init__( newPath, "eos" )

    dirName = os.path.dirname( destination.lfn )
    if dirName == '':
        dirName = '.'
    directory = cmsFile( dirName, "eos" )
    if not directory.isdir():
        print >> sys.stderr, "Destination directory %s does not exist." % directory.lfn
        sys.exit(1)

    if destination.isfile() and force==False:
        print >> sys.stderr, "%s already exists, will not overwrite without option." % destination.lfn
        sys.exit(1)
    elif force==True:
        print >> sys.stderr, "Will overwrite %s due to force flag." % destination.lfn

def validateCopy( first, second, debug ):
    """
    _validateCopy_

    Check file size is the same
    """

    if not debug:
        firstSize = first.size()
        secondSize = second.size()
        if firstSize != secondSize:
            print >> sys.stderr, """
File sizes disagree:
%s: %d 
%s: %d
""" % ( first.lfn, firstSize, second.lfn, secondSize )
            sys.exit(1)

def usage():
    print """
cmsStage: [-hfd] <source> <destination>

<source> and <destination> can be LFNs or local file names

A LFN should be CMS standard starting /store/.
A local file name can be relative or absolute path name.

The destination directory must already exist.

-h produce this message
-f force overwrite
-d debug output only, no execution
"""

if __name__ == '__main__':
    main( sys.argv[1:] )
