#!/usr/bin/env python
"""
_cmsPfn_

Return PFN for read access (for example for use with ROOT)

"""

import sys
import os
import getopt
import cmsIO

def main( argv ):
    (args, tfcProt ) = parseOpts( argv )

    for arg in args:
        entity = cmsIO.cmsFile( arg, tfcProt )
        print entity.pfn

def parseOpts( argv ):
    """
    _parseOpts_

    Parse the command line arguments
    """

    tfcProt = "rfio"

    try:
        opts, args = getopt.getopt(argv, "hsp:", ["help","protocol="])
    except getopt.GetoptError:
        print >> sys.stderr, "Unable to parse argument list"
        usage()
        sys.exit(2)

    for o, a in opts:
        if o in ( "-h", "--help" ):
            usage()
            sys.exit()
        if o == "-s":
            tfcProt = "stageout"
        if o in ( "-p", "--protocol" ):
            tfcProt = a

    if len(args) == 0:
        print >> sys.stderr, "Expected at least one non-option argument"
        usage()
        sys.exit(2)

    return ( args, tfcProt )

def usage():
    print """
cmsPfn: [-hs] <dir/file> <dir/file> ...

<dir/file> can be LFNs or local file names

A LFN should be CMS standard starting /store/.
A local file name can be relative or absolute path name.

-h produce this message
-s show stageout PFN
"""

if __name__ == '__main__':
    main( sys.argv[1:] )
